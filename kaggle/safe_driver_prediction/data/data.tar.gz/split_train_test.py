#!/usr/bin/env python
# -*- coding:utf-8 -*-

import os,sys
import collections
import random

if __name__=='__main__':
  data_file  = sys.argv[1]
  test_rate  = float(sys.argv[2])
  header = int(sys.argv[3])
  d = collections.defaultdict(list) 
  header_str = ""
  f = open(data_file,'rb')
  for line in f:
    if header == 1:
      header_str = line.strip()
      header = 0
      continue
    sid = line.split(',')[1]  #必要的时候修改分隔符
    d[sid].append(line.strip())
    
  f_train = open(data_file + '_train.txt','wb')
  f_test  = open(data_file + '_test.txt','wb')
  if len(header_str) > 0:
    f_train.write(header_str+ '\n')
    f_test.write(header_str+ '\n')

  for k,v in d.items():
    random.shuffle(v)
    index = int(len(v)*(1-test_rate))
    for i in range(index):
      f_train.write(v[i] + '\n')

    for i in range(index,len(v)):
      f_test.write(v[i]+'\n')    
    
  f_train.close()
  f_test.close()


